
package megainterface;

public class Jogador3DAO {
    
}
