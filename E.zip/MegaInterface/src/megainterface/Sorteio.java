
package megainterface;

import java.util.Arrays;
import java.util.Random;

public class Sorteio {
    public Sorteio(){
        int[] loteria = new int[6];
        int[] jogo = new int[6];
        int[] num = new int[61];
        //variável usada para gerar os jogos ordenados
        int ordena;
        int n;
        int i;
        int j;
        Random rand;
        int randomNum;
        for(n=1; n<=3000; n++){
            //gerando o array random
            for(i=0;i<6;i++){
                //sorteio
                rand = new Random();
                randomNum = 1 + rand.nextInt(60);
                loteria[i] = randomNum;
            }
        //resorteio
        for(i=0;i<6;i++){       
            for(j=i+1;j<=5;j++){
                do{
                    if(loteria[j]==loteria[i]){
                        rand = new Random();
                        randomNum = 1 + rand.nextInt(60);
                        loteria[i] = randomNum;   
                    }
                }
                while(loteria[j]==loteria[i]);
            }
        }
        for(i=0;i<6;i++){            
            num[loteria[i]]++;
        }
            //print da tela
            //System.out.println("Jogo " + n + ": --> " + (Arrays.toString(loteria)));
            for (i=0; i<6; i++){
                for (j=i+1;j<=5;j++){
                    if (loteria[j] < loteria[i]){
                        ordena = loteria[i];
                        loteria[i] = loteria[j];
                        loteria[j] = ordena;
                    }   
                }       
            }
               // System.out.println("Jogo ordenado " + n + ": --> " + (Arrays.toString(loteria)) + "\n");     
            }
    }
}
    

