
package megainterface;

public class MegaInterface {

    public static void main(String[] args) {
        telaPrincipal m = new telaPrincipal();
        m.setVisible(true);
    }
    
}
