
package megainterface;

import java.sql.Connection;

public class Jogador1DAO {
    private final Connection connection;

    public Jogador1DAO(Connection connection) {
        this.connection = connection;
    }
    
}
