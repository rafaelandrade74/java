/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package conexaoSQLDB;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Nardo
 */
public class DataBaseConexao {
   
    public static  java.sql.Connection getConnection() throws SQLException {
        try {
            
            Class.forName("C:\\Users\\Nardo\\AppData\\Roaming\\SQL Developer\\system4.1.3.20.78\\o.sqldeveloper.12.2.0.20.78\\projects");
                String myDB = "MegaInterface_java";
                String usuario = "ronaldo2";
                String password = "190504";
                
            System.out.println("Conectando...");
            java.sql.Connection cnx = DriverManager.getConnection(myDB,usuario,password);
            System.out.println("Conectado!");
                       
            return cnx;
            
        } catch (SQLException ex) {
            System.out.println(ex.getMessage());
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(DataBaseConexao.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }    
}
