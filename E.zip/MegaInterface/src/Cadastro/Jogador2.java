
package Cadastro;

public class Jogador2 {
    
}
